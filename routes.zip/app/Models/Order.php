<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    //  protected $fillable = ['artwork', 'style_name', 'order_no', 'body_color', 'print_quality', 'parts_name', 'print_color','total_qty'];   
}